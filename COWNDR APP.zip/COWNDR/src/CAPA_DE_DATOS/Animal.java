/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CAPA_DE_DATOS;

/**
 *
 * @author Karito
 */
public class Animal {
    private int id;
    private String sexo;
    private String hierro;
    private int edad;
    private String informacionVeterinaria;
    private String grupo;

    public Animal(int id, String grupo, String sexo, String hierro, int edad, String informacionVeterinaria) {
        this.id = id;
        this.grupo = grupo;
        this.sexo = sexo;
        this.hierro = hierro;
        this.edad = edad;
        this.informacionVeterinaria = informacionVeterinaria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getHierro() {
        return hierro;
    }

    public void setHierro(String hierro) {
        this.hierro = hierro;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getInformacionVeterinaria() {
        return informacionVeterinaria;
    }

    public void setInformacionVeterinaria(String informacionVeterinaria) {
        this.informacionVeterinaria = informacionVeterinaria;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }
}
