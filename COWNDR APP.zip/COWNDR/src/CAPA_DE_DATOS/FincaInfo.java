/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CAPA_DE_DATOS;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Karito
 */
    public class FincaInfo {
        private String nombre;
        private String otraInformacion;
        private List<String> potreros = new ArrayList<>();

        // Constructor
        public FincaInfo(String nombre, String otraInformacion) {
            this.nombre = nombre;
            this.otraInformacion = otraInformacion;
        }

        // Getters y setters (si es necesario)
        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getOtraInformacion() {
            return otraInformacion;
        }

        public void setOtraInformacion(String otraInformacion) {
            this.otraInformacion = otraInformacion;
        }

        public List<String> getPotreros() {
            return potreros;
        }

        public void agregarPotrero(String potrero) {
            potreros.add(potrero);
        }
    }

