/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CAPA_DE_DATOS;

/**
 *
 * @author Karito
 */
public class Grupo {
    private String nombre;
    private int cantidadAnimales;

    public Grupo(String nombre, int cantidadAnimales) {
        this.nombre = nombre;
        this.cantidadAnimales = cantidadAnimales;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidadAnimales() {
        return cantidadAnimales;
    }

    public void setCantidadAnimales(int cantidadAnimales) {
        this.cantidadAnimales = cantidadAnimales;
    }
}
