/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CAPA_DE_LÓGICA_DE_NEGOCIOS;

import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;

/**
 *
 * @author Karito
 */
public class CustomComboBoxRenderer extends DefaultListCellRenderer {

    @Override
    public Component getListCellRendererComponent(
            JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        
        // Llama al método original de DefaultListCellRenderer para obtener el JLabel predeterminado
        JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        
        // Personaliza el JLabel según tus necesidades
        label.setFont(new java.awt.Font("Courier New", java.awt.Font.PLAIN, 18)); // Cambia la fuente, sin negrita
        label.setHorizontalAlignment(javax.swing.SwingConstants.LEFT); // Alinea el texto a la izquierda

        // Cambia el color de fondo a blanco cuando no está desplegado
        if (index == -1) {
            label.setBackground(java.awt.Color.WHITE);
            label.setForeground(list.getForeground());
        } else {
            // Cambia los colores de fondo y primer plano si el elemento está seleccionado o no
            if (isSelected) {
                label.setBackground(list.getSelectionBackground());
                label.setForeground(list.getSelectionForeground());
            } else {
                label.setBackground(list.getBackground());
                label.setForeground(list.getForeground());
            }
        }

        label.setOpaque(true);
        return label;
    }
}
