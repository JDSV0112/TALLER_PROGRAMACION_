package CAPA_DE_LÓGICA_DE_NEGOCIOS;


import CAPA_DE_DATOS.USUARIO;
import java.util.HashMap;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Karito
 */
public class GestorUsuario {
    private static GestorUsuario instancia;
    public HashMap<String, USUARIO> usuariosPorCorreo;

    private GestorUsuario() { 
        usuariosPorCorreo = new HashMap<>();
    }

    public static GestorUsuario getInstancia() {
        if (instancia == null) {
            instancia = new GestorUsuario();
        }
        return instancia;
    }

    public void registrarUsuario(USUARIO usuario) {
        usuariosPorCorreo.put(usuario.getCorreo(), usuario);
        
    }

    public USUARIO buscarUsuarioPorCorreo(String correo) {
        USUARIO usuario = usuariosPorCorreo.get(correo);
        return usuario;
    }
}
