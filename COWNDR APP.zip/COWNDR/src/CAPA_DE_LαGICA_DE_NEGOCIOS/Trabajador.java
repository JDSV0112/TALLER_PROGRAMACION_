/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CAPA_DE_LÓGICA_DE_NEGOCIOS;

/**
 *
 * @author Karito
 */
public class Trabajador {
    private String nombre;
    private String cargo;
    private double sueldo;
    private String fechaPago;

    // Constructor
    public Trabajador(String nombre, String cargo, double sueldo, String fechaPago) {
        this.nombre = nombre;
        this.cargo = cargo;
        this.sueldo = sueldo;
        this.fechaPago = fechaPago;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(String fechaPago) {
        this.fechaPago = fechaPago;
    }
    
    
}
