package CAPA_DE_PRESENTACIÓN;


import CAPA_DE_DATOS.FincaInfo;
import CAPA_DE_DATOS.Grupo;
import CAPA_DE_DATOS.USUARIO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * 
 */
public class HOME extends javax.swing.JFrame {
    // Referencias a instancias importantes
    public HOME homeInstance; // Referencia a la instancia actual de HOME
    public SALUD_ANIMAL saludAnimalInstance; // Referencia a la instancia de SALUD_ANIMAL
    private SOPORTE existingInstance; // Instancia de SOPORTE
    private MENU existingMenuInstance; // Instancia de MENU
    private USUARIO usuario; // Instancia de USUARIO
    
    // Modelos de datos
    private DefaultListModel<String> fincasListModel = new DefaultListModel<>(); // Modelo para la lista de fincas
    private Map<String, FincaInfo> fincaInfoMap = new HashMap<>(); // Mapa para almacenar información adicional de las fincas
    
    // Listas y mapas de datos
    private static Map<String, HOME> homeInstances = new HashMap<>(); // Mapa para mantener instancias de HOME
    private List<SALUD_ANIMAL> saludAnimalInstances = new ArrayList<>(); // Lista para mantener instancias de SALUD_ANIMAL
    private Map<String, List<Grupo>> gruposPorFinca = new HashMap<>(); // Mapa para mapear grupos por finca
    
    // Variables relacionadas con las fincas
    public String nombreFinca; // Nombre de la finca actualmente seleccionada
    private String nombreGrupo; //Nombre del grupo
    public int numeroFincasDisponibles; // Número de fincas disponibles
    public int numeroFincas = 0; // Número total de fincas creadas
    private int cantidadAnimales; // Cantidad total de animales en las fincas

    /**
     * Creates new form PAGINA_INICIO
     * @param nombreFinca
     * @param existingInstance
     * @param existingMenuInstance
     * @param saludAnimalInstance
     * @param usuario
     */
    public HOME(String nombreFinca, SOPORTE existingInstance, MENU existingMenuInstance, SALUD_ANIMAL saludAnimalInstance, USUARIO usuario) {
        initComponents(); // Inicializa los componentes de la interfaz
        
        this.setLocationRelativeTo(null); // Centra la ventana en la pantalla
        setResizable(false); // Deshabilita la posibilidad de redimensionar la ventana
        
        // Asigna las instancias y datos recibidos a los atributos de la clase
        this.homeInstance = this;
        this.saludAnimalInstance = saludAnimalInstance;
        this.nombreFinca = nombreFinca;
        this.usuario = usuario;
        this.existingInstance = new SOPORTE(homeInstance, existingMenuInstance);
        this.existingMenuInstance = new MENU(homeInstance, saludAnimalInstance, existingInstance, usuario);
        
        // Agrega automáticamente la finca "Finca 1" al crear la instancia HOME
        agregarFinca("FINCA 1");
        
        // Crea un nuevo grupo y lo agrega a la finca 1
        Grupo grupo1 = new Grupo("Grupo 1", 10);
        homeInstance.agregarGrupo("FINCA 1", grupo1);
        
        // Verifica si el nombre de la finca no es nulo antes de establecerlo en jLabel7
        if (nombreFinca != null && !nombreFinca.isEmpty()) {
            jLabel7.setText(nombreFinca);
        } else {
            jLabel7.setText("FINCA");
        }
        
        jPanel2.setVisible(false); // Oculta el panel jPanel2
        
        // Oculta las etiquetas relacionadas con las fincas y los potreros
        FINCA_1.setVisible(false);
        FINCA_2.setVisible(false);
        FINCA_3.setVisible(false);
        FINCA_4.setVisible(false);
        FINCA_5.setVisible(false);
        FINCA_6.setVisible(false);
        
        jLfinca_1.setVisible(false);
        jLfinca_2.setVisible(false);
        jLfinca_3.setVisible(false);
        jLfinca_4.setVisible(false);
        jLfinca_5.setVisible(false);
        jLfinca_6.setVisible(false);
        
        jListFincas.setModel(fincasListModel); // Establece el modelo de lista para jListFincas
    }
    
    // Método para obtener el modelo de lista de fincas
    public DefaultListModel<String> getFincasListModel() {
        return fincasListModel;
    }
    
    // Método para agregar una instancia de SALUD_ANIMAL a la lista
    public void agregarSaludAnimalInstance(SALUD_ANIMAL instance) {
        saludAnimalInstances.add(instance);
    }

    // Método para obtener la lista de instancias de SALUD_ANIMAL
    public List<SALUD_ANIMAL> getInstanciasSaludAnimal() {
        return saludAnimalInstances;
    }
    
    //Establece las instancias existentes de SOPORTE y MENU.
    public void setExistingInstances(SOPORTE existingInstance, MENU existingMenuInstance) {
        this.existingInstance = existingInstance;
        this.existingMenuInstance = existingMenuInstance;
    }

    //Establece las instancias existentes de HOME y MENU en la clase SOPORTE.
    public void setExistingInstances(HOME homeInstance, MENU existingMenuInstance) {
        this.homeInstance = homeInstance;
        this.existingMenuInstance = existingMenuInstance;
    }

    //Obtiene el número total de fincas.
    
    public int getNumeroFincas() {
        return numeroFincas;
    }

    //Establece el número total de fincas.
    public void setNumeroFincas(int numeroFincas) {
        this.numeroFincas = numeroFincas;
    }

    //Incrementa el número total de fincas en uno.
    public void incrementarNumeroFincas() {
        numeroFincas++;
    }

    //Agrega una nueva finca al modelo de lista y al mapa de información de fincas.
    public void agregarFinca(String nombreFinca) { 
        fincasListModel.addElement(nombreFinca);
        // Refresca la vista de la lista para reflejar el cambio
        jListFincas.setModel(fincasListModel);
        // Mantiene un registro de la finca en el programa
        agregarInformacionFinca(nombreFinca, "", new ArrayList<>());
    }

    //Agrega un grupo a una finca específica.
    public void agregarGrupo(String nombreFinca, Grupo grupo) {
        // Obtiene la lista de grupos asociados con la finca
        List<Grupo> grupos = gruposPorFinca.getOrDefault(nombreFinca, new ArrayList<>());
        // Agrega el nuevo grupo a la lista
        grupos.add(grupo);
        // Actualiza la lista de grupos asociados con la finca
        gruposPorFinca.put(nombreFinca, grupos);
    }

    //Agrega información de una finca al mapa de información de fincas.
    public void agregarInformacionFinca(String nombreFinca, String otraInformacion, List<String> potreros) {
        FincaInfo fincaInfo = new FincaInfo(nombreFinca, otraInformacion);
        for (String potrero : potreros) {
            fincaInfo.agregarPotrero(potrero);
        }
        fincaInfoMap.put(nombreFinca, fincaInfo);
    }

    //Muestra el nombre del potrero y la finca en las etiquetas proporcionadas.
    public void mostrarPotreroYFinca(JLabel finca, JLabel jLfinca, String nombrePotrero, String nombreFinca) {
        finca.setVisible(true);
        // Establece el texto del potrero
        finca.setText(nombrePotrero);
        jLfinca.setText(nombreFinca);
        jLfinca.setVisible(true);
    }

    //Obtiene la etiqueta de la finca en la posición especificada.
    public JLabel getFincaLabel(int index) {
        switch (index) {
            case 1:
                return FINCA_1;
            case 2:
                return FINCA_2;
            case 3:
                return FINCA_3;
            case 4:
                return FINCA_4;
            case 5:
                return FINCA_5;
            case 6:
                return FINCA_6;
            default:
                return null;
        }
    }

    //Obtiene la etiqueta de la finca jLfinca_X en la posición especificada.
    public JLabel getJLFincaLabel(int index) {
        switch (index) {
            case 1:
                return jLfinca_1;
            case 2:
                return jLfinca_2;
            case 3:
                return jLfinca_3;
            case 4:
                return jLfinca_4;
            case 5:
                return jLfinca_5;
            case 6:
                return jLfinca_6;
            default:
                return null;
        }
    }
    
    //Obtiene la instancia actual de HOME.
    public HOME getHomeInstance() {
        return this.homeInstance;
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        FINCA_1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLfinca_2 = new javax.swing.JLabel();
        FINCA_2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListFincas = new javax.swing.JList<>();
        FINCA_3 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        FINCA_4 = new javax.swing.JLabel();
        FINCA_5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        FINCA_6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLfinca_1 = new javax.swing.JLabel();
        jLfinca_3 = new javax.swing.JLabel();
        jLfinca_4 = new javax.swing.JLabel();
        jLfinca_5 = new javax.swing.JLabel();
        jLfinca_6 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel1.setMaximumSize(new java.awt.Dimension(383, 642));
        jPanel1.setMinimumSize(new java.awt.Dimension(383, 642));
        jPanel1.setPreferredSize(new java.awt.Dimension(383, 642));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("MS UI Gothic", 0, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("C O W N D R");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 7, 222, 49));

        FINCA_1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/c_3.jpg"))); // NOI18N
        FINCA_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        FINCA_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FINCA_1MouseClicked(evt);
            }
        });
        jPanel1.add(FINCA_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 163, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/vac.jpeg"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 7, -1, 49));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 62, 369, 10));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-2 (2).jpg"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 78, -1, -1));

        jLabel3.setFont(new java.awt.Font("MS UI Gothic", 0, 36)); // NOI18N
        jLabel3.setText("?");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 76, -1, -1));

        jLfinca_2.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLfinca_2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLfinca_2.setText("POTRERO");
        jPanel1.add(jLfinca_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 240, 160, 40));

        FINCA_2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/c_3.jpg"))); // NOI18N
        FINCA_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        FINCA_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FINCA_2MouseClicked(evt);
            }
        });
        jPanel1.add(FINCA_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 163, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 23, 150, 0));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel17.setFont(new java.awt.Font("MS UI Gothic", 1, 18)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("CREAR FINCA");
        jLabel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("MS UI Gothic", 1, 18)); // NOI18N
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("CREAR POTRERO");
        jLabel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });

        jListFincas.setFont(new java.awt.Font("Courier New", 0, 18)); // NOI18N
        jListFincas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListFincasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jListFincas);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 140));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 420, 170, 150));

        FINCA_3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/c_3.jpg"))); // NOI18N
        FINCA_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        FINCA_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FINCA_3MouseClicked(evt);
            }
        });
        jPanel1.add(FINCA_3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 163, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-4.jpg"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 570, -1, -1));

        FINCA_4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/c_3.jpg"))); // NOI18N
        FINCA_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        FINCA_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FINCA_4MouseClicked(evt);
            }
        });
        jPanel1.add(FINCA_4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 163, -1));

        FINCA_5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/c_3.jpg"))); // NOI18N
        FINCA_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        FINCA_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FINCA_5MouseClicked(evt);
            }
        });
        jPanel1.add(FINCA_5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 163, -1));
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 641, -1, -1));
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 500, 20, 20));
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 500, 20, 20));

        FINCA_6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/c_3.jpg"))); // NOI18N
        FINCA_6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        FINCA_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FINCA_6MouseClicked(evt);
            }
        });
        jPanel1.add(FINCA_6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 420, 163, -1));

        jLabel7.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("FINCA");
        jLabel7.setToolTipText("");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 260, 40));

        jLfinca_1.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLfinca_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLfinca_1.setText("POTRERO");
        jPanel1.add(jLfinca_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 160, 40));

        jLfinca_3.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLfinca_3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLfinca_3.setText("POTRERO");
        jPanel1.add(jLfinca_3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 160, 40));

        jLfinca_4.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLfinca_4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLfinca_4.setText("POTRERO");
        jPanel1.add(jLfinca_4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 380, 160, 40));

        jLfinca_5.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLfinca_5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLfinca_5.setText("POTRERO");
        jPanel1.add(jLfinca_5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 160, 40));

        jLfinca_6.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLfinca_6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLfinca_6.setText("POTRERO");
        jPanel1.add(jLfinca_6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 520, 160, 40));

        jLabel28.setText("                ");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 0, 50, 640));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, 10, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 661, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        existingMenuInstance.setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        existingInstance.setVisible(true);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        if (jPanel2.isVisible()) {
            jPanel2.setVisible(false); 
        } else {
            jPanel2.setVisible(true); 
        }
    }//GEN-LAST:event_jLabel14MouseClicked
    private void fincaMouseClicked(java.awt.event.MouseEvent evt) {
        this.setVisible(false);
        new SALUD_ANIMAL(nombreGrupo, cantidadAnimales, homeInstance, existingInstance, existingMenuInstance).setVisible(true);               
    }
    private void FINCA_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FINCA_1MouseClicked
        fincaMouseClicked(evt);
    }//GEN-LAST:event_FINCA_1MouseClicked

    private void FINCA_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FINCA_2MouseClicked
        fincaMouseClicked(evt);
    }//GEN-LAST:event_FINCA_2MouseClicked

    private void FINCA_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FINCA_3MouseClicked
        fincaMouseClicked(evt);
    }//GEN-LAST:event_FINCA_3MouseClicked

    private void FINCA_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FINCA_4MouseClicked
        fincaMouseClicked(evt);
    }//GEN-LAST:event_FINCA_4MouseClicked

    private void FINCA_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FINCA_5MouseClicked
        fincaMouseClicked(evt);
    }//GEN-LAST:event_FINCA_5MouseClicked

    private void FINCA_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FINCA_6MouseClicked
        fincaMouseClicked(evt);
    }//GEN-LAST:event_FINCA_6MouseClicked
    
    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked
        new CREAR_FINCA(this, existingInstance, existingMenuInstance).setVisible(true);
    }//GEN-LAST:event_jLabel17MouseClicked

    private void jListFincasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListFincasMouseClicked
        if (evt.getClickCount() == 2) {
            int selectedIndex = jListFincas.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedFinca = jListFincas.getSelectedValue();
                HOME existingHomeInstance = homeInstances.get(selectedFinca);
                if (existingHomeInstance != null) {
                    existingHomeInstance.setVisible(true);
                    return;
                }
                SOPORTE newSoporteInstance = new SOPORTE(null, existingMenuInstance); // Inicializar SOPORTE
                MENU newMenuInstance = new MENU(null, saludAnimalInstance, newSoporteInstance, usuario); // Inicializar MENU
                HOME newFincaInstance = new HOME(selectedFinca, newSoporteInstance, newMenuInstance, saludAnimalInstance, usuario);

                newSoporteInstance.setExistingInstances(newFincaInstance, newMenuInstance);
                newFincaInstance.setExistingInstances(newSoporteInstance, newMenuInstance);

                homeInstances.put(selectedFinca, newFincaInstance);
                newFincaInstance.setVisible(true);
            }
        }
    }//GEN-LAST:event_jListFincasMouseClicked
    private void switchToFinca(String selectedFinca) {
        HOME existingHome = homeInstances.get(selectedFinca);
        if (existingHome != null) {
            existingHome.setVisible(true); // Mostrar la ventana existente
            this.setVisible(false);
        } else {
            HOME newHome = createOrUpdateHome(selectedFinca);
            newHome.setVisible(true);
        }
    }

    private HOME createOrUpdateHome(String selectedFinca) {
        HOME newHome = new HOME(selectedFinca, existingInstance, existingMenuInstance, saludAnimalInstance, usuario);

        // Transferir información de las fincas
        for (int i = 0; i < fincasListModel.size(); i++) {
            String finca = fincasListModel.getElementAt(i);
            if (!finca.equals(selectedFinca)) {
                newHome.agregarFinca(finca);
                // Transferir información de potreros
                FincaInfo fincaInfo = fincaInfoMap.get(finca);
                if (fincaInfo != null) {
                    for (String potrero : fincaInfo.getPotreros()) {
                        newHome.mostrarPotreroYFinca(newHome.getFincaLabel(i + 1), newHome.getJLFincaLabel(i + 1), potrero, finca);
                    }
                }
            }
        }
        // Agregar la finca seleccionada a la nueva instancia HOME
        newHome.agregarFinca(selectedFinca);

        // Agregar potreros a la nueva instancia HOME para la finca seleccionada
        FincaInfo selectedFincaInfo = fincaInfoMap.get(selectedFinca);
        if (selectedFincaInfo != null) {
            for (String potrero : selectedFincaInfo.getPotreros()) {
                newHome.mostrarPotreroYFinca(newHome.getFincaLabel(1), newHome.getJLFincaLabel(1), potrero, selectedFinca);
            }
        }

        // Actualizar el mapa de instancias HOME
        homeInstances.put(selectedFinca, newHome);
        return newHome;
    }
    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        // Verificar si hay fincas creadas
        if (fincasListModel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay fincas creadas. Debes crear al menos una finca antes de agregar potreros.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // Limpiar la selección actual en el jListFincas
            jListFincas.clearSelection();

            // Obtener el índice de la finca seleccionada
            int selectedIndex = jListFincas.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedFinca = (String) jListFincas.getSelectedValue();
                this.setVisible(false);
                new CREAR_POTRERO(this, selectedFinca, existingInstance, existingMenuInstance).setVisible(true);
            } else {
                // Si no hay ninguna finca seleccionada, abrir la ventana para crear un potrero
                this.setVisible(false);
                new CREAR_POTRERO(this, "",existingInstance, existingMenuInstance).setVisible(true);
            }
        }
    }//GEN-LAST:event_jLabel19MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            
            public void run() {
                new PAGINA_INICIO().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel FINCA_1;
    public javax.swing.JLabel FINCA_2;
    public javax.swing.JLabel FINCA_3;
    public javax.swing.JLabel FINCA_4;
    public javax.swing.JLabel FINCA_5;
    public javax.swing.JLabel FINCA_6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    public javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    public javax.swing.JLabel jLfinca_1;
    public javax.swing.JLabel jLfinca_2;
    public javax.swing.JLabel jLfinca_3;
    public javax.swing.JLabel jLfinca_4;
    public javax.swing.JLabel jLfinca_5;
    public javax.swing.JLabel jLfinca_6;
    public javax.swing.JList<String> jListFincas;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
