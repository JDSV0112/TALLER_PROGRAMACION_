package CAPA_DE_PRESENTACIÓN;


import CAPA_DE_DATOS.Animal;
import CAPA_DE_DATOS.Grupo;
import CAPA_DE_DATOS.USUARIO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author juani
 */
public class SALUD_ANIMAL extends javax.swing.JFrame {
    private AÑADIR_GRUPO añadirGrupo;
    private HOME homeInstance;
    public SALUD_ANIMAL saludAnimalInstance;
    private SOPORTE existingInstance;
    private MENU existingMenuInstance;
    private USUARIO usuario;
    public List<JLabel> ANIMAL;
    public List<JLabel> jLanimal = new ArrayList<>();
    private List<String> nombresGrupos = new ArrayList<>();
    private Map<String, List<Animal>> animalesPorGrupo = new HashMap<>();
    private String nombreGrupo;
    private int cantidadAnimales;

    /**
     * Constructor para inicializar la ventana de gestión de salud de animales.
     * @param nombreGrupo El nombre del grupo de animales.
     * @param cantidadAnimales La cantidad de animales en el grupo.
     * @param homeInstance La instancia de la ventana principal HOME.
     * @param existingInstance La instancia existente de SOPORTE.
     * @param existingMenuInstance La instancia existente de MENU.
     */
    public SALUD_ANIMAL(String nombreGrupo, int cantidadAnimales, HOME homeInstance, SOPORTE existingInstance, MENU existingMenuInstance) {
        initComponents();

        this.setLocationRelativeTo(null);
        setResizable(false);

        // Creamos una nueva instancia de HOME si no se proporciona
        if (homeInstance == null) {
            homeInstance = new HOME(nombreGrupo, existingInstance, existingMenuInstance, this, usuario);
        }
        
        this.nombreGrupo = nombreGrupo;
        this.cantidadAnimales = cantidadAnimales;     
        this.homeInstance = homeInstance;
        this.existingInstance = existingInstance;
        this.existingMenuInstance = existingMenuInstance;
        
        this.nombresGrupos = new ArrayList<>();
        this.animalesPorGrupo = new HashMap<>();
        this.jLanimal = new ArrayList<>();
        this.ANIMAL = new ArrayList<>();

        // Inicialización de añadirGrupo
        añadirGrupo = new AÑADIR_GRUPO(homeInstance, this, existingInstance, existingMenuInstance);
        
        ANIMAL_1.setName("ANIMAL_1");
        ANIMAL_2.setName("ANIMAL_2");
        ANIMAL_3.setName("ANIMAL_3");
        ANIMAL_4.setName("ANIMAL_4");
        ANIMAL_5.setName("ANIMAL_5");
        ANIMAL_6.setName("ANIMAL_6");
        
        jLanimal_1.setName("ANIMAL_1");
        jLanimal_2.setName("ANIMAL_2");
        jLanimal_3.setName("ANIMAL_3");
        jLanimal_4.setName("ANIMAL_4");
        jLanimal_5.setName("ANIMAL_5");
        jLanimal_6.setName("ANIMAL_6");

        ANIMAL.add(ANIMAL_1);
        ANIMAL.add(ANIMAL_2);
        ANIMAL.add(ANIMAL_3);
        ANIMAL.add(ANIMAL_4);
        ANIMAL.add(ANIMAL_5);
        ANIMAL.add(ANIMAL_6);
        
        jLanimal.add(jLanimal_1);
        jLanimal.add(jLanimal_2);
        jLanimal.add(jLanimal_3);
        jLanimal.add(jLanimal_4);
        jLanimal.add(jLanimal_5);
        jLanimal.add(jLanimal_6);
        
        // Asegurarse de que todos los componentes estén ocultos al inicio
        for (JLabel label : ANIMAL) {
            label.setVisible(false);
        }
        for (JLabel label : jLanimal) {
            label.setVisible(false);
        }

    }
    
    private void actualizarJLanimales() {
        for (int i = 0; i < jLanimal.size(); i++) {
            if (i < nombresGrupos.size()) {
                jLanimal.get(i).setText(nombresGrupos.get(i));
                jLanimal.get(i).setVisible(true);
                ANIMAL.get(i).setVisible(true);
            } else {
                jLanimal.get(i).setVisible(false);
                ANIMAL.get(i).setVisible(false);
            }
        }
    }

    // Método para agregar un nuevo grupo
    public void agregarGrupo(String nuevoGrupo, int cantidadAnimales) {
        if (nombresGrupos.size() >= 6) {
            JOptionPane.showMessageDialog(this, "Se ha alcanzado el límite máximo de grupos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        nombresGrupos.add(nuevoGrupo);
        List<Animal> listaAnimales = new ArrayList<>();
        for (int i = 0; i < cantidadAnimales; i++) {
            listaAnimales.add(new Animal(0, nuevoGrupo, "", "", 0, ""));
        }

        animalesPorGrupo.put(nuevoGrupo, listaAnimales);
        actualizarJLanimales();
    }
    
    public List<Animal> obtenerAnimalesDelGrupo(String grupo) {
        return animalesPorGrupo.get(grupo);
    }

    public void agregarGrupo() {
        añadirGrupo.setVisible(true);
    }

    public void grupoAgregado(String nombreGrupo, int cantidadAnimales) {
        ANIMALES_FICHA animalesFicha = new ANIMALES_FICHA(nombreGrupo, nombresGrupos.indexOf(nombreGrupo), homeInstance, this, cantidadAnimales, existingInstance, existingMenuInstance);
        animalesFicha.setVisible(true);
    }

    public String getNombreGrupo() {
        return nombreGrupo;
    }

    public void setNombreGrupo(String nombreGrupo) {
        this.nombreGrupo = nombreGrupo;
    }

    public int getCantidadAnimales() {
        return cantidadAnimales;
    }

    public void setCantidadAnimales(int cantidadAnimales) {
        this.cantidadAnimales = cantidadAnimales;
    }

    public HOME getHomeInstance() {
        return this.homeInstance;
    }
    public void setHomeInstance(HOME homeInstance) {
        this.homeInstance = homeInstance;
    }
    


    private void ANIMALMouseClicked(java.awt.event.MouseEvent evt) {
        JLabel label = (JLabel) evt.getSource();
        String name = label.getName();

        if (name == null) {
            JOptionPane.showMessageDialog(this, "El nombre del JLabel es null", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int animalIndex = Integer.parseInt(name.substring(name.lastIndexOf("_") + 1)) - 1;

        if (animalIndex >= nombresGrupos.size()) {
            JOptionPane.showMessageDialog(this, "Índice fuera de límites", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombreGrupo = nombresGrupos.get(animalIndex);

        ANIMALES_FICHA animalesFicha = new ANIMALES_FICHA(nombreGrupo, animalIndex, homeInstance, this, cantidadAnimales, existingInstance, existingMenuInstance);
        animalesFicha.setVisible(true);
        this.setVisible(false);
    }
    public void actualizarAnimal(Animal animalActualizado) {
        List<Animal> animales = animalesPorGrupo.get(animalActualizado.getGrupo());
        if (animales != null) {
            for (int i = 0; i < animales.size(); i++) {
                if (animales.get(i).getId() == animalActualizado.getId()) {
                    animales.set(i, animalActualizado);
                    break;
                }
            }
        }
    }
    
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        ANIMAL_1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLanimal_2 = new javax.swing.JLabel();
        ANIMAL_2 = new javax.swing.JLabel();
        ANIMAL_3 = new javax.swing.JLabel();
        ANIMAL_4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        ANIMAL_5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        ANIMAL_6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLanimal_1 = new javax.swing.JLabel();
        jLanimal_3 = new javax.swing.JLabel();
        jLanimal_4 = new javax.swing.JLabel();
        jLanimal_5 = new javax.swing.JLabel();
        jLanimal_6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("MS UI Gothic", 0, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("C O W N D R");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 7, 222, 49));

        ANIMAL_1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-10.jpg"))); // NOI18N
        ANIMAL_1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        ANIMAL_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ANIMAL_1MouseClicked(evt);
            }
        });
        jPanel1.add(ANIMAL_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 163, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/vac.jpeg"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 7, -1, 49));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 62, 369, 10));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-2 (2).jpg"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 78, -1, -1));

        jLabel3.setFont(new java.awt.Font("MS UI Gothic", 0, 36)); // NOI18N
        jLabel3.setText("?");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 76, -1, -1));

        jLanimal_2.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLanimal_2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLanimal_2.setText("ANIMAL 2");
        jPanel1.add(jLanimal_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, 160, 40));

        ANIMAL_2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-10.jpg"))); // NOI18N
        ANIMAL_2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        ANIMAL_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ANIMAL_2MouseClicked(evt);
            }
        });
        jPanel1.add(ANIMAL_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 163, -1));

        ANIMAL_3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-10.jpg"))); // NOI18N
        ANIMAL_3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        ANIMAL_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ANIMAL_3MouseClicked(evt);
            }
        });
        jPanel1.add(ANIMAL_3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 163, -1));

        ANIMAL_4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-10.jpg"))); // NOI18N
        ANIMAL_4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        ANIMAL_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ANIMAL_4MouseClicked(evt);
            }
        });
        jPanel1.add(ANIMAL_4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 163, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 23, 150, 0));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel17.setFont(new java.awt.Font("MS UI Gothic", 1, 18)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("AÑADIR GRUPO");
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
            .addComponent(jSeparator4)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 180, 40));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 510, -1, 61));

        ANIMAL_5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-10.jpg"))); // NOI18N
        ANIMAL_5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        ANIMAL_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ANIMAL_5MouseClicked(evt);
            }
        });
        jPanel1.add(ANIMAL_5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 163, -1));
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 641, -1, -1));
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 500, 20, 20));
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 500, 20, 20));

        ANIMAL_6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-10.jpg"))); // NOI18N
        ANIMAL_6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        ANIMAL_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ANIMAL_6MouseClicked(evt);
            }
        });
        jPanel1.add(ANIMAL_6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 420, 163, -1));

        jLabel7.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("SALUD ANIMAL");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 78, 260, 35));

        jLanimal_1.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLanimal_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLanimal_1.setText("ANIMAL 1");
        jPanel1.add(jLanimal_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 160, 40));

        jLanimal_3.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLanimal_3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLanimal_3.setText("ANIMAL 3");
        jPanel1.add(jLanimal_3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 160, 40));

        jLanimal_4.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLanimal_4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLanimal_4.setText("ANIMAL 4");
        jPanel1.add(jLanimal_4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, 160, 40));

        jLanimal_5.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLanimal_5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLanimal_5.setText("ANIMAL 5");
        jPanel1.add(jLanimal_5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 510, 160, 40));

        jLanimal_6.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        jLanimal_6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLanimal_6.setText("ANIMAL 6");
        jPanel1.add(jLanimal_6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 510, 160, 40));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/C-4.jpg"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(294, Short.MAX_VALUE)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, 568, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 661, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        if (jPanel2.isVisible()) {
            jPanel2.setVisible(false); 
        } else {
            jPanel2.setVisible(true); 
        }
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        existingMenuInstance.setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        existingInstance.setVisible(true);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked
        if (homeInstance != null) {
            this.setVisible(false);
            new AÑADIR_GRUPO(homeInstance, this, existingInstance, existingMenuInstance).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo obtener la instancia de HOME.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jLabel17MouseClicked

    private void ANIMAL_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ANIMAL_1MouseClicked
        ANIMALMouseClicked(evt);
    }//GEN-LAST:event_ANIMAL_1MouseClicked

    private void ANIMAL_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ANIMAL_2MouseClicked
        ANIMALMouseClicked(evt);
    }//GEN-LAST:event_ANIMAL_2MouseClicked

    private void ANIMAL_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ANIMAL_3MouseClicked
        ANIMALMouseClicked(evt);
    }//GEN-LAST:event_ANIMAL_3MouseClicked

    private void ANIMAL_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ANIMAL_4MouseClicked
        ANIMALMouseClicked(evt);
    }//GEN-LAST:event_ANIMAL_4MouseClicked

    private void ANIMAL_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ANIMAL_5MouseClicked
        ANIMALMouseClicked(evt);
    }//GEN-LAST:event_ANIMAL_5MouseClicked

    private void ANIMAL_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ANIMAL_6MouseClicked
        ANIMALMouseClicked(evt);
    }//GEN-LAST:event_ANIMAL_6MouseClicked
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PAGINA_INICIO.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PAGINA_INICIO().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel ANIMAL_1;
    public javax.swing.JLabel ANIMAL_2;
    public javax.swing.JLabel ANIMAL_3;
    public javax.swing.JLabel ANIMAL_4;
    public javax.swing.JLabel ANIMAL_5;
    public javax.swing.JLabel ANIMAL_6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    public javax.swing.JLabel jLanimal_1;
    public javax.swing.JLabel jLanimal_2;
    public javax.swing.JLabel jLanimal_3;
    public javax.swing.JLabel jLanimal_4;
    public javax.swing.JLabel jLanimal_5;
    public javax.swing.JLabel jLanimal_6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator4;
    // End of variables declaration//GEN-END:variables

}
